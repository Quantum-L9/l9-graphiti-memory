<!--
skill_schema: 1
parent: l9-deploy-phase6-operator
layer: asset
role: checksum_manifest_metadata
tags: [manifest, sha256, integrity]
owner: igor_beylin
status: active
version: 1.0.0
updated: 2026-07-26
-->
# Checksum Manifest Metadata

`MANIFEST.sha256` covers every regular file in this package except the checksum manifest itself.
