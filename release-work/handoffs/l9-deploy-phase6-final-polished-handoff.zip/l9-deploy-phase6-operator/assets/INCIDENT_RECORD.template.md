<!--
skill_schema: 1
parent: l9-deploy-phase6-operator
layer: asset
role: incident_template
tags: [incident, rollback, staging]
owner: igor_beylin
status: active
version: 1.0.0
updated: 2026-07-26
-->
# Phase 6 Incident Record

- Incident ID:
- Scenario:
- Detected at:
- Operator:
- Staging host:
- Workflow run ID:
- Plan digest:
- Prior healthy release:
- Observed failure:
- Containment action:
- Rollback action:
- Final image digest:
- Final configuration identity:
- Final state hash:
- Final health:
- OIDC identity revoked or disabled, if applicable:
- Secret-leakage result:
- Evidence paths:
- Decision: NO-GO
